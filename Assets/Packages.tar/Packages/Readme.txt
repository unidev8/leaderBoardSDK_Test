This is SDK package for getting leaderboards of Server and client.

Main Function
GetLeaderBoardAPIData (url)
url: Get one leaderboard API on server or client 
GetLeaderBoardsArray()

Using GetLeaderBoardAPIData function of this libray, the result is stored at private member of SDK
We could get leaderboard values using GetLeaderBoardsArray function.